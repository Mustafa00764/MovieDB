package com.example.wowmovie_.adapter

import com.example.wowmovie_.model.My

class MyAdapter(val list: ArrayList<My>) {

}