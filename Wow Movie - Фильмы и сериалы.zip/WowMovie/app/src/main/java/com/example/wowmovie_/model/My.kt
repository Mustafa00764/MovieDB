package com.example.wowmovie_.model

class My {
}