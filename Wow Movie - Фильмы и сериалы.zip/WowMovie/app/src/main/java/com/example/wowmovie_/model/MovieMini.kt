package com.example.wowmovie_.model

import android.media.Image

data class MovieMini (
    val image:String,
    val text:String,
    val janr:String,
    val ball:String,
    val llcolor:Int,


)


