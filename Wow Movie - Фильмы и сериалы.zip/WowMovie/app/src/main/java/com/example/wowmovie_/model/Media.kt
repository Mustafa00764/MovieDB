package com.example.wowmovie_.model

data class Media (
    val text:String,
    val stories:ArrayList<MovieMini>?=null,
)
