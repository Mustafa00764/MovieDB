package com.example.wowmovie_.adapter

class LoadingAdapter {
}